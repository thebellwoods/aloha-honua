# Hello Playdate

<img src="menu.png" style="width: 400px" />

In this challenge, I want to create an arrow and series of 3 menu items. The arrow will be positioned besides an menu item and it should appear selected.

main things I want to learn include how to:

- draw the arrow and menu items
- use array of objects
- use fonts
- path to images within this
- play a sound on selection

## Blog Post

?

## Credits

much thanks to:

- [panels](https://github.com/cadin/panels/tree/main)
- [2048](https://github.com/hteumeuleu/2048)
- [wanda](https://www.pinterest.ca/pin/337910778306440720/)
